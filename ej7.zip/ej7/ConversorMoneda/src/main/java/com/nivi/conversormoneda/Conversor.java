/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nivi.conversormoneda;

import javax.jws.WebMethod;
import javax.jws.WebService;


/**
 *
 * @author nicov
 */
@WebService
public class Conversor {
    @WebMethod
    public float convertir(String pais1, String pais2, float montof){
        try {
            //Obtener ISO CODE de cada pais

            org.oorsprong.websamples.CountryInfoService service = new org.oorsprong.websamples.CountryInfoService();
            org.oorsprong.websamples.CountryInfoServiceSoapType port = service.getCountryInfoServiceSoap12();
            // Obtiene el ISO CODE de pais1
            java.lang.String isoCode1 = port.countryISOCode(pais1);
            // Obtiene el ISO CODE de pais2
            java.lang.String isoCode2 = port.countryISOCode(pais2);

            //Obtener currency de cada pais
            // TODO process result here
            org.oorsprong.websamples.TCurrency currency1 = port.countryCurrency(isoCode1);
            org.oorsprong.websamples.TCurrency currency2 = port.countryCurrency(isoCode2);
            //Convertir
            com.nivi.calculadoramoneda.CalculadoraService service2 = new com.nivi.calculadoramoneda.CalculadoraService();
            com.nivi.calculadoramoneda.Calculadora port2 = service2.getCalculadoraPort();
            // TODO process result here
            float result = port2.convertir(currency1.getSISOCode(), currency2.getSISOCode(), montof);
            return result;

        } catch (Exception ex) {
            System.out.println("Error: " + ex);
            return -1f;
        }
    }
    
}
