/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.nivi.conversormoneda;

import javax.xml.ws.Endpoint;

/**
 *
 * @author nicov
 */
public class ConversorMoneda {

    public static void main(String[] args) {
        Endpoint.publish("http://localhost:3000/ConversorMoneda", new Conversor());
    }
}
