/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nivi.convertidorwebapp;

import java.text.DecimalFormat;
import java.util.HashMap;
import spark.ModelAndView;
import spark.Request;
import spark.Response;
import spark.Route;
import spark.template.velocity.VelocityTemplateEngine;

/**
 *
 * @author nicov
 */
class ConversorControlador {

    public static Route getConversion = (Request req, Response res) -> {
        float result = -1;
        boolean exito = false;
        if (!req.queryParams().isEmpty()) {
            String pais1 = req.queryParams("pais1");
            String pais2 = req.queryParams("pais2");
            float monto = Float.parseFloat(req.queryParams("monto"));

            try { // Call Web Service Operation
                com.nivi.conversormoneda.ConversorService service = new com.nivi.conversormoneda.ConversorService();
                com.nivi.conversormoneda.Conversor port = service.getConversorPort();
                // TODO process result here
                result = port.convertir(pais1, pais2, monto);
                exito = true;
            } catch (Exception ex) {
                System.out.println("Error: " + ex);
            }
        }

        DecimalFormat df = new DecimalFormat("#.##");

        HashMap model = new HashMap();
        model.put("exito", exito);
        model.put("result", df.format(result));
        model.put("template", "templates/ConvertidorWebApp.vtl");

        return new VelocityTemplateEngine().render(new ModelAndView(model, "templates/layout.vtl"));
    };
}
