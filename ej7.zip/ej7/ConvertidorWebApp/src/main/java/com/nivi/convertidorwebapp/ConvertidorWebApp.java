/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.nivi.convertidorwebapp;
import static spark.Spark.*;
/**
 *
 * @author nicov
 */
public class ConvertidorWebApp {

    public static void main(String[] args) {
        get("/convertir", ConversorControlador.getConversion);
    }
}
