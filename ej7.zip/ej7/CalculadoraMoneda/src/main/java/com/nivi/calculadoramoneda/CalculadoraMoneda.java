/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.nivi.calculadoramoneda;

import javax.xml.ws.Endpoint;

/**
 *
 * @author nicov
 */
public class CalculadoraMoneda {

    public static void main(String[] args) {
        Endpoint.publish("http://localhost:8080/CalculadoraMoneda", new Calculadora());
    }
}
