/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nivi.calculadoramoneda;

import java.util.HashMap;
import java.util.Map;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
/**
 *
 * @author nicov
 */
@WebService
public class Calculadora {

    //Mapa de Moneda:EquivalenteEnDolares 
    Map<String, Float> dolar;

    private void init() {
        this.dolar.put("USD", 1f);
        this.dolar.put("ARS", 893.82f);
        this.dolar.put("BRL", 5.25f);
        this.dolar.put("CLP", 917.58f);
    }

    public Calculadora() {
        this.dolar = new HashMap<>();
        init();
    }

    //La conversión primero pasa a dolares y de dolares a la siguiente moneda
    @WebMethod
    public float convertir(String moneda1, String moneda2, float monto) {
        float equivalence1 = this.dolar.get(moneda1);
        float equivalence2 = this.dolar.get(moneda2);
        float result = (monto * equivalence2) / equivalence1;
        return result;
    }
}
