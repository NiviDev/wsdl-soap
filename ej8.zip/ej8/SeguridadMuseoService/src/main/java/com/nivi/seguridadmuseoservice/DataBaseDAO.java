/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nivi.seguridadmuseoservice;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nicov
 */
class DataBaseDAO {

    List<Integer> dataBase;

    public DataBaseDAO() {
        dataBase = new ArrayList<>();
        dataBase.add(10);
        dataBase.add(20);
        dataBase.add(30);
        dataBase.add(40);
        dataBase.add(50);
    }
    
    public List<Integer> getDataBase(){
        return dataBase;
    }
}
