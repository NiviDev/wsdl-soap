/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.nivi.seguridadmuseoservice;

import javax.xml.ws.Endpoint;

/**
 *
 * @author nicov
 */
public class SeguridadMuseoService {

    public static void main(String[] args) {
        Endpoint.publish("http://localhost:8080/seguridadWS", new Reconocimiento());
    }
}
