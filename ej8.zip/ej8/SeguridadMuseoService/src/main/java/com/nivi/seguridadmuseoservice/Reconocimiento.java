/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nivi.seguridadmuseoservice;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author nicov
 */
@WebService
public class Reconocimiento {

    static boolean alerta = false;
    private static final int[] dataBase = {10, 20, 30, 40, 50};

    @WebMethod
    public boolean faceID(int stream) {
        for (int i : dataBase) {
            if (i == stream) {
                setAlerta(true);
                return true;
            }
        }

        return false;
    }

    public void setAlerta(boolean alerta) {
        Reconocimiento.alerta = alerta;
    }

    @WebMethod
    public boolean getAlerta() {
        return alerta;
    }
}
